#include "hp_vectra.h"


enum layer_names {
    _BASE,
    _FN
};

enum custom_keycodes {
    TEST = 400,
};


bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    if (record->event.pressed) {                              //Code for macros
        switch(keycode) {
    case TEST:
    if (record->event.pressed) {
        SEND_STRING("TEST");
        } else {}break;
    }
}
#ifdef CONSOLE_ENABLE //Console Debug
    uprintf("KL: kc: 0x%04X, col: %u, row: %u, pressed: %b, time: %u, interrupt: %b, count: %u\n", keycode, record->event.key.col, record->event.key.row, record->event.pressed, record->event.time, record->tap.interrupted, record->tap.count);
#endif
    return true;
    
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {

    [_BASE] = KEYMAP(
        TEST,    KC_F1,   KC_F2,   KC_F3,   KC_F4,   KC_F5,   KC_F6,   KC_F7,   KC_F8,   KC_F9,  KC_F10,  KC_F11,  KC_F12,                       KC_PSCR, KC_SLCK, KC_PAUS,   RESET,
        KC_GRV,     KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0, KC_MINS,  KC_EQL,   KC_NO, KC_BSPC,     KC_NLCK, KC_PSLS, KC_PAST, KC_PMNS,
        KC_TAB,     KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P, KC_LBRC, KC_RBRC, KC_BSLS,                KC_P7,   KC_P8,   KC_P9, KC_PPLS,
        KC_CAPS,    KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L, KC_SCLN, KC_QUOT,   KC_NO,  KC_ENT,                KC_P4,   KC_P5,   KC_P6,   KC_NO,
        KC_LSFT,   KC_NO,    KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M, KC_COMM,  KC_DOT, KC_SLSH,   KC_NO, KC_LSFT,                KC_P1,   KC_P2,   KC_P3, KC_PENT,
        KC_LCTL,          KC_LALT,                             KC_SPC,                             KC_LALT,         KC_LCTL,                         KC_NO,   KC_P0, KC_PDOT,   KC_NO
    ),
    [_FN] = KEYMAP(
        KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,                       KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,
        KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,     KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,
        KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,              KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,
        KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,              KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,
        KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,              KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,
        KC_TRNS,          KC_TRNS,                            KC_TRNS,                            KC_TRNS,          KC_TRNS,                       KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS
    ),
};





void led_set(uint8_t usb_led) {

	if (usb_led & (1 << USB_LED_NUM_LOCK)) {
		DDRF |= (1 << 4); PORTF &= ~(1 << 4);
	} else {
		DDRF &= ~(1 << 4); PORTF &= ~(1 << 4);
	}

	if (usb_led & (1 << USB_LED_CAPS_LOCK)) {
		DDRF |= (1 << 1); PORTF &= ~(1 << 1);
	} else {
		DDRF &= ~(1 << 1); PORTF &= ~(1 << 1);
	}

	if (usb_led & (1 << USB_LED_SCROLL_LOCK)) {
		DDRF |= (1 << 0); PORTF &= ~(1 << 0);
	} else {
		DDRF &= ~(1 << 0); PORTF &= ~(1 << 0);
	}

	if (usb_led & (1 << USB_LED_KANA)) {
		DDRE |= (1 << 6); PORTE &= ~(1 << 6);
	} else {
		DDRE &= ~(1 << 6); PORTE &= ~(1 << 6);
	}

}
